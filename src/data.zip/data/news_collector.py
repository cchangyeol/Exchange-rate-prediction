"""
NEXUS v4 — 시간별 다중 뉴스 수집기

기능:
  - RSS 피드 자동 수집 (Reuters, Bloomberg, 연합뉴스, 한국경제 등)
  - GDELT API 보조 수집
  - 지수 감쇠(Exponential Decay) 시간 가중치 적용
  - /api/news/collect  → 뉴스 수집 API
  - /api/news/analyze  → 다중 뉴스 분석 API

사용:
  pip install feedparser requests
"""

import os, json, time, math, re
from datetime import datetime, timezone
from typing import List, Dict, Optional
import urllib.request
import urllib.parse

try:
    import feedparser
    FEEDPARSER_OK = True
except ImportError:
    FEEDPARSER_OK = False
    print("[WARN] feedparser 없음 → pip install feedparser")

try:
    import requests as req_lib
    REQUESTS_OK = True
except ImportError:
    REQUESTS_OK = False

# ── RSS 피드 목록 ─────────────────────────────────────────────
RSS_FEEDS = [
    # 글로벌 경제
    {"name": "Reuters Business",  "url": "https://feeds.reuters.com/reuters/businessNews",      "lang": "en", "weight": 1.2},
    {"name": "Reuters Finance",   "url": "https://feeds.reuters.com/reuters/UKFinancialServices","lang": "en", "weight": 1.2},
    {"name": "Bloomberg Markets", "url": "https://feeds.bloomberg.com/markets/news.rss",         "lang": "en", "weight": 1.3},
    {"name": "MarketWatch",       "url": "https://feeds.content.dowjones.io/public/rss/mw_marketpulse","lang":"en","weight":1.0},
    # 한국 경제
    {"name": "연합뉴스 경제",     "url": "https://www.yna.co.kr/rss/economy.xml",               "lang": "ko", "weight": 1.1},
    {"name": "한국경제",          "url": "https://feeds.hankyung.com/article/economy.xml",       "lang": "ko", "weight": 1.0},
    {"name": "매일경제",          "url": "https://rss.mk.co.kr/economy/",                        "lang": "ko", "weight": 1.0},
    # 아시아
    {"name": "Nikkei Asia",       "url": "https://asia.nikkei.com/rss/feed/nar",                 "lang": "en", "weight": 1.0},
]

# GDELT API (무료, 실시간 전세계 뉴스)
GDELT_API = "https://api.gdeltproject.org/api/v2/doc/doc"

# 시간 감쇠 상수: 단기(<= 24h)에서 기본값
# 0.3 → 1시간 전 × 1.0, 3시간 전 × 0.40, 6시간 전 × 0.17
DECAY_LAMBDA_DEFAULT = 0.3


def parse_period(period: str) -> int:
    """
    "3h" / "24h" / "3d" / "1w" / "1m" / "1y" → 시간(int) 변환.
    숫자만 들어오면 시간으로 간주.

    1m = 30일, 1y = 365일 (근사)
    """
    if period is None:
        return 3
    s = str(period).strip().lower()
    if not s:
        return 3
    # 숫자만 (예: "12")
    if s.isdigit():
        return max(1, int(s))
    # 단위 분리: 마지막 글자
    unit = s[-1]
    try:
        num = int(s[:-1])
    except ValueError:
        return 3
    mult = {"h": 1, "d": 24, "w": 168, "m": 24 * 30, "y": 24 * 365}.get(unit)
    if mult is None:
        return 3
    return max(1, num * mult)


def adaptive_decay_lambda(range_hours: int) -> float:
    """
    범위에 따라 감쇠 상수 조정.
    범위 끝(가장 오래된 뉴스)에서 가중치 ~0.05가 되도록 설정.
    → exp(-lambda * range_hours) = 0.05 → lambda = 3.0 / range_hours

    예시:
      범위 6h   → lambda 0.3   (1시간 전 weight=0.74, 6시간 전 weight=0.16) — 기본값
      범위 24h  → lambda 0.125 (1시간 전 weight=0.88, 24시간 전 weight=0.05)
      범위 168h → lambda 0.018 (24시간 전 weight=0.65, 168시간 전 weight=0.05)
      범위 720h → lambda 0.004 (240시간 전 weight=0.38, 720시간 전 weight=0.05)
    """
    if range_hours <= 6:
        return DECAY_LAMBDA_DEFAULT  # 매우 단기(≤6h)는 가파른 감쇠
    return 3.0 / range_hours


def time_weight(published_at: Optional[datetime], now: Optional[datetime] = None,
                lam: Optional[float] = None) -> float:
    """지수 감쇠 시간 가중치"""
    if published_at is None:
        return 0.5
    if now is None:
        now = datetime.now(timezone.utc)
    if published_at.tzinfo is None:
        published_at = published_at.replace(tzinfo=timezone.utc)
    hours_ago = max(0, (now - published_at).total_seconds() / 3600)
    if lam is None:
        lam = DECAY_LAMBDA_DEFAULT
    return round(math.exp(-lam * hours_ago), 4)


def _parse_entry_time(entry) -> Optional[datetime]:
    """feedparser entry에서 발행 시각 추출"""
    for field in ("published_parsed", "updated_parsed", "created_parsed"):
        t = getattr(entry, field, None)
        if t:
            try:
                return datetime(*t[:6], tzinfo=timezone.utc)
            except Exception:
                continue
    return None


def _clean_text(text: str) -> str:
    """HTML 태그, 특수문자 정리"""
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"&[a-z]+;", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def collect_rss(hours: int = 3, max_per_feed: int = 5,
                lam: Optional[float] = None) -> List[Dict]:
    """
    RSS 피드에서 최근 N시간 뉴스 수집

    ⚠️ RSS는 보통 최근 24~48시간 기사만 제공. 더 긴 범위 요청해도 RSS가 보유한
    만큼만 반환. 장기 범위는 GDELT에 의존하세요.
    """
    if not FEEDPARSER_OK:
        return []

    now     = datetime.now(timezone.utc)
    cutoff  = now.timestamp() - hours * 3600
    results = []

    for feed_info in RSS_FEEDS:
        try:
            feed = feedparser.parse(feed_info["url"])
            count = 0
            for entry in feed.entries:
                if count >= max_per_feed:
                    break
                pub_dt = _parse_entry_time(entry)

                # 시간 필터
                if pub_dt and pub_dt.timestamp() < cutoff:
                    continue

                title   = _clean_text(getattr(entry, "title", ""))
                summary = _clean_text(getattr(entry, "summary", ""))
                url     = getattr(entry, "link", "")
                if not title:
                    continue

                tw = time_weight(pub_dt, now, lam=lam)
                fw = round(tw * feed_info["weight"], 4)

                results.append({
                    "title":        title,
                    "text":         summary[:500],
                    "url":          url,
                    "source":       feed_info["name"],
                    "lang":         feed_info["lang"],
                    "published_at": pub_dt.isoformat() if pub_dt else None,
                    "raw_weight":   feed_info["weight"],
                    "time_weight":  tw,
                    "final_weight": fw,
                })
                count += 1
        except Exception as e:
            print(f"  [SKIP] {feed_info['name']}: {e}")
            continue

    # 최종 가중치 기준 정렬
    results.sort(key=lambda x: x["final_weight"], reverse=True)
    return results


def collect_gdelt_range(keyword: str, start_dt: datetime, end_dt: datetime,
                         max_results: int = 100,
                         lam: Optional[float] = None,
                         use_cache: bool = True) -> List[Dict]:
    """
    GDELT 과거 날짜 범위 검색 (백테스트용).
    `timespan` 대신 `startdatetime` / `enddatetime` 사용 → 임의 과거 기간 query.

    use_cache=True (기본): SQLite 캐시 우선. 동일 (keyword, 날짜범위)면 GDELT 안 두드림.
    """
    if start_dt.tzinfo is None:
        start_dt = start_dt.replace(tzinfo=timezone.utc)
    if end_dt.tzinfo is None:
        end_dt = end_dt.replace(tzinfo=timezone.utc)

    # 캐시 조회
    if use_cache:
        try:
            import gdelt_cache
            cached = gdelt_cache.get_cached(keyword, start_dt, end_dt)
            if cached is not None:
                # time_weight 재계산 (현재 lam에 맞게)
                for a in cached:
                    if a.get("published_at"):
                        try:
                            pt = datetime.fromisoformat(a["published_at"])
                            a["time_weight"]  = time_weight(pt, end_dt, lam=lam)
                            a["final_weight"] = round(a["time_weight"], 4)
                        except Exception:
                            pass
                print(f"  [GDELT cache HIT] {len(cached)}건 (keyword={keyword[:30]}, {start_dt.date()}~{end_dt.date()})")
                return cached
        except ImportError:
            pass

    sd = start_dt.strftime("%Y%m%d%H%M%S")
    ed = end_dt.strftime("%Y%m%d%H%M%S")
    max_results = min(max_results, 250)
    params = {
        "query":         keyword,
        "mode":          "artlist",
        "maxrecords":    max_results,
        "format":        "json",
        "startdatetime": sd,
        "enddatetime":   ed,
        "sort":          "DateDesc",
    }
    url = GDELT_API + "?" + urllib.parse.urlencode(params)
    results = []
    # 429 대응: 지수 백오프 재시도 (15s, 30s, 60s)
    for attempt, delay in enumerate([15, 30, 60, 0], 1):
        try:
            with urllib.request.urlopen(url, timeout=15) as r:
                data = json.loads(r.read().decode())
            for a in data.get("articles", []):
                title = _clean_text(a.get("title", ""))
                if not title:
                    continue
                pub_str = a.get("seendatetime", "")
                pub_dt = None
                if pub_str:
                    try:
                        pub_dt = datetime.strptime(pub_str, "%Y%m%dT%H%M%SZ").replace(tzinfo=timezone.utc)
                    except ValueError:
                        pass
                tw = time_weight(pub_dt, end_dt, lam=lam)
                results.append({
                    "title":        title,
                    "text":         "",
                    "url":          a.get("url", ""),
                    "source":       f"GDELT ({a.get('domain','')})",
                    "lang":         "en",
                    "published_at": pub_dt.isoformat() if pub_dt else None,
                    "raw_weight":   1.0,
                    "time_weight":  tw,
                    "final_weight": round(tw, 4),
                })
            # 성공 시 캐시 저장
            if use_cache:
                try:
                    import gdelt_cache
                    gdelt_cache.put_cached(keyword, start_dt, end_dt, results, status="ok")
                except Exception:
                    pass
            return results
        except Exception as e:
            msg = str(e)
            if "429" in msg and delay > 0:
                print(f"  [GDELT range 429] {delay}s 대기 후 재시도 ({attempt}/3)")
                time.sleep(delay)
                continue
            print(f"  [GDELT range SKIP] {e}")
            return results
    return results


def collect_news_range(start_dt: datetime, end_dt: datetime,
                       keyword: str = "Korea exchange rate KRW won economy",
                       max_total: int = 30) -> Dict:
    """
    과거 특정 날짜 범위의 뉴스 수집 (백테스트용).
    RSS는 과거 데이터 없으니 GDELT만 사용.
    """
    hours = max(1, int((end_dt - start_dt).total_seconds() / 3600))
    lam = adaptive_decay_lambda(hours)
    # GDELT 한 번에 최대 250 → 충분
    articles = collect_gdelt_range(keyword, start_dt, end_dt,
                                    max_results=min(250, max_total * 3), lam=lam)
    # 중복 제거
    seen = set(); deduped = []
    for n in articles:
        key = re.sub(r"\s+", "", n["title"].lower())[:40]
        if key not in seen:
            seen.add(key); deduped.append(n)
    # 시간 가중치 기준 정렬 + 자르기
    deduped.sort(key=lambda x: x["final_weight"], reverse=True)
    deduped = deduped[:max_total]
    total_w = sum(n["final_weight"] for n in deduped) or 1.0
    for n in deduped:
        n["normalized_weight"] = round(n["final_weight"] / total_w, 4)
    return {
        "articles":     deduped,
        "total":        len(deduped),
        "start":        start_dt.isoformat(),
        "end":          end_dt.isoformat(),
        "hours":        hours,
        "decay_lambda": round(lam, 4),
    }


def _gdelt_timespan(hours: int) -> str:
    """
    hours를 GDELT timespan 포맷으로 변환 (가독성 좋은 단위로).
    GDELT는 h/d/w/m 접미사 지원 (m=month=30일 근사).
      <= 24h → "Nh"
      <= 72h → "Nh" (3일은 hours 유지)
      <= 14*24h → "Nd"
      <= 8*168h → "Nw"
      그 외   → "Nm" (월)
    """
    if hours <= 72:
        return f"{hours}h"
    days = hours // 24
    if days <= 14:
        return f"{days}d"
    weeks = hours // 168
    if weeks <= 8:
        return f"{weeks}w"
    months = max(1, hours // (24 * 30))
    return f"{months}m"


def collect_gdelt(keyword: str = "exchange rate KRW OR Korea economy",
                  hours: int = 3, max_results: int = 10,
                  lam: Optional[float] = None) -> List[Dict]:
    """
    GDELT API로 키워드 기반 뉴스 수집.
    장기 범위(>24h)에서 RSS 한계를 보완.
    """
    now    = datetime.now(timezone.utc)
    timespan = _gdelt_timespan(hours)
    # GDELT 최대 250 articles per call
    max_results = min(max_results, 250)
    params = {
        "query":      keyword,
        "mode":       "artlist",
        "maxrecords": max_results,
        "format":     "json",
        "timespan":   timespan,
        "sort":       "DateDesc",
    }
    url = GDELT_API + "?" + urllib.parse.urlencode(params)
    results = []
    try:
        with urllib.request.urlopen(url, timeout=8) as r:
            data = json.loads(r.read().decode())
        articles = data.get("articles", [])
        for a in articles:
            title = _clean_text(a.get("title", ""))
            if not title:
                continue
            pub_str = a.get("seendatetime", "")
            pub_dt  = None
            if pub_str:
                try:
                    pub_dt = datetime.strptime(pub_str, "%Y%m%dT%H%M%SZ").replace(tzinfo=timezone.utc)
                except ValueError:
                    pass
            tw = time_weight(pub_dt, now, lam=lam)
            results.append({
                "title":        title,
                "text":         "",
                "url":          a.get("url", ""),
                "source":       f"GDELT ({a.get('domain','')})",
                "lang":         "en",
                "published_at": pub_dt.isoformat() if pub_dt else None,
                "raw_weight":   1.0,
                "time_weight":  tw,
                "final_weight": round(tw * 1.0, 4),
            })
    except Exception as e:
        print(f"  [GDELT SKIP] {e}")
    return results


def collect_news(hours: int = 3, max_total: int = 20,
                 keyword: str = "", period: Optional[str] = None) -> Dict:
    """
    RSS + GDELT 통합 수집 후 가중치 정규화.

    Args:
        hours: 수집 범위 시간 (period 우선)
        period: "3h"/"24h"/"7d"/"2w"/"1m"/"1y" 형식. 지정되면 hours 무시
        max_total: 최대 반환 기사 수
        keyword: GDELT 검색어 (없으면 기본값 사용)

    범위에 따라 동적 조정:
      · DECAY_LAMBDA: 가장 오래된 뉴스가 weight≈0.05가 되도록
      · max_per_feed: 장기일수록 더 많이
      · GDELT maxrecords: 장기일수록 더 많이
    """
    if period:
        hours = parse_period(period)

    lam = adaptive_decay_lambda(hours)
    # 범위별 수집량 조정
    if hours <= 24:
        rss_per_feed = 5
        gdelt_max    = 10
    elif hours <= 72:        # ~3일
        rss_per_feed = 10
        gdelt_max    = 30
    elif hours <= 24*7:      # ~1주
        rss_per_feed = 20
        gdelt_max    = 60
    elif hours <= 24*30:     # ~1개월
        rss_per_feed = 30
        gdelt_max    = 120
    else:                    # 그 이상
        rss_per_feed = 50
        gdelt_max    = 250

    span_label = _gdelt_timespan(hours)
    print(f"[INFO] 뉴스 수집 시작 — 범위 {hours}시간 ({span_label}), 감쇠상수 lam={lam:.4f}, 최대 {max_total}건")
    if hours > 48:
        print("       ⚠️ RSS는 보통 최근 24~48시간만 보유. 장기 범위는 GDELT가 주력.")

    rss_news   = collect_rss(hours=hours, max_per_feed=rss_per_feed, lam=lam)
    gdelt_news = collect_gdelt(
        keyword=keyword or "Korea exchange rate economy stock market won KRW",
        hours=hours, max_results=gdelt_max, lam=lam
    )

    all_news = rss_news + gdelt_news

    # 중복 제거 (제목 첫 40자 비교)
    seen_titles = set()
    deduped = []
    for n in all_news:
        key = re.sub(r"\s+", "", n["title"].lower())[:40]
        if key not in seen_titles:
            seen_titles.add(key)
            deduped.append(n)

    # 시간 가중치 기준 재정렬 (최신·고가중치 우선)
    deduped.sort(key=lambda x: x["final_weight"], reverse=True)

    # 최종 가중치 정규화 (top-N 후)
    deduped = deduped[:max_total]
    total_w = sum(n["final_weight"] for n in deduped) or 1.0
    for n in deduped:
        n["normalized_weight"] = round(n["final_weight"] / total_w, 4)

    print(f"[OK] 수집 완료: {len(deduped)}건 (RSS {len(rss_news)}건 + GDELT {len(gdelt_news)}건)")

    return {
        "articles":           deduped,
        "total":              len(deduped),
        "hours":              hours,
        "period":             period or f"{hours}h",
        "timespan_label":     span_label,
        "decay_lambda":       round(lam, 4),
        "collected_at":       datetime.now().isoformat(),
        "weighted_avg_score": None,
    }


def demo_news(hours: int = 3) -> Dict:
    """
    RSS 수집 실패 시 사용하는 데모 뉴스
    (feedparser 미설치 환경에서도 UI 동작 확인 가능)
    """
    now = datetime.now(timezone.utc)
    demo = [
        {"title":"Fed, 금리 동결 결정… 연내 인하 가능성 시사",
         "text":"연방준비제도(Fed)가 기준금리를 동결했다. 파월 의장은 연내 금리 인하 가능성을 열어뒀다.",
         "source":"Reuters (Demo)","lang":"ko","hours_ago":0.5},
        {"title":"엔비디아, AI 칩 수요 폭증으로 분기 매출 사상 최대",
         "text":"엔비디아의 3분기 매출이 전년 대비 200% 급증했다. H100 GPU 공급 부족이 지속되고 있다.",
         "source":"Bloomberg (Demo)","lang":"ko","hours_ago":1.2},
        {"title":"중동 긴장 고조… 호르무즈 해협 통행 위협",
         "text":"이란 혁명수비대가 호르무즈 해협에서 군사적 긴장을 고조시키고 있다. 유가가 급등했다.",
         "source":"Reuters (Demo)","lang":"ko","hours_ago":2.1},
        {"title":"달러/원 환율, 미 고용지표 호조로 1350원대 상승",
         "text":"미국 비농업 고용지표가 예상치를 크게 상회하며 달러 강세가 이어졌다.",
         "source":"연합뉴스 (Demo)","lang":"ko","hours_ago":2.8},
        {"title":"삼성전자, HBM 차세대 메모리 엔비디아 공급 계약 체결",
         "text":"삼성전자가 엔비디아와 HBM3E 대규모 공급 계약을 체결했다고 밝혔다.",
         "source":"한국경제 (Demo)","lang":"ko","hours_ago":0.3},
    ]
    articles = []
    for d in demo:
        pub_dt = datetime.fromtimestamp(now.timestamp() - d["hours_ago"]*3600, tz=timezone.utc)
        tw = time_weight(pub_dt, now)
        articles.append({
            "title":        d["title"],
            "text":         d["text"],
            "url":          "",
            "source":       d["source"],
            "lang":         d["lang"],
            "published_at": pub_dt.isoformat(),
            "raw_weight":   1.0,
            "time_weight":  tw,
            "final_weight": tw,
            "normalized_weight": 0.0,  # 아래서 재계산
        })
    total_w = sum(a["final_weight"] for a in articles) or 1.0
    for a in articles:
        a["normalized_weight"] = round(a["final_weight"] / total_w, 4)

    return {
        "articles":           articles,
        "total":              len(articles),
        "hours":              hours,
        "collected_at":       datetime.now().isoformat(),
        "weighted_avg_score": None,
        "is_demo":            True,
    }
