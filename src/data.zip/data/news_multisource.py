"""
NEXUS 멀티 소스 뉴스 수집기
==============================

기존 GDELT 1개 소스 → 다중 소스 통합으로 시점당 기사 수를 10~20배 확장.

소스:
  1) Google News RSS — 10개 키워드 변형 (한/영), API 키 불필요
  2) 한국 경제지 RSS — Yonhap, 매경, 한경, 머니투데이 등
  3) 글로벌 RSS — CNBC, Investing.com, FT, Bloomberg
  4) GDELT API — 기존 (백테스트 호환용 fallback)
  5) 네이버 뉴스 검색 API — 일 25,000건 (.env에 키 있을 때 자동 활성)

특징:
  · 모든 소스에서 가져온 후 URL/title 기준 중복 제거
  · time_weight: 최신 기사에 가중치 (analyzer가 사용)
  · 관련성 필터 적용 가능 (relevance_filter.py 재사용)
"""
import json
import os
import re
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional

UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) AppleWebKit/537.36 NEXUS-FX/1.0"


# ============================================================
# 키워드 / 소스 정의
# ============================================================
KO_KEYWORDS = [
    "원달러 환율",
    "원화 환율",
    "한국은행 기준금리",
    "외환시장",
    "수출입 무역수지",
    "한미 금리차",
]

EN_KEYWORDS = [
    "Korean Won exchange rate",
    "KRW USD",
    "Bank of Korea interest rate",
    "South Korea trade balance",
    "South Korea won weak",
    "Federal Reserve dollar Korea",
]

# RSS feeds (API 키 불필요)
RSS_FEEDS = {
    "Yonhap 경제":       "https://www.yna.co.kr/rss/economy.xml",
    "매일경제 증권":     "https://www.mk.co.kr/rss/30100041/",
    "한국경제 증권":     "https://www.hankyung.com/feed/finance",
    "CNBC Currencies":   "https://www.cnbc.com/id/19854910/device/rss/rss.html",
    "Investing.com FX":  "https://www.investing.com/rss/news_285.rss",
    "FT Currencies":     "https://www.ft.com/currencies?format=rss",
    "Bloomberg Markets": "https://feeds.bloomberg.com/markets/news.rss",
}


# ============================================================
# 유틸
# ============================================================
def _http_get(url: str, timeout: int = 10, headers: Optional[Dict] = None) -> str:
    h = {"User-Agent": UA}
    if headers:
        h.update(headers)
    req = urllib.request.Request(url, headers=h)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", errors="ignore")


def _strip_html(s: str) -> str:
    """간단 HTML 태그 제거"""
    if not s:
        return ""
    s = re.sub(r"<[^>]+>", " ", s)
    s = re.sub(r"&[a-z]+;", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _parse_pubdate(s: Optional[str]) -> Optional[datetime]:
    """다양한 RSS pubDate 포맷 파싱"""
    if not s:
        return None
    for fmt in [
        "%a, %d %b %Y %H:%M:%S %z",
        "%a, %d %b %Y %H:%M:%S GMT",
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%d %H:%M:%S",
    ]:
        try:
            dt = datetime.strptime(s.strip(), fmt)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except Exception:
            continue
    return None


def _time_weight(pub: Optional[datetime], reference: Optional[datetime] = None,
                 half_life_hours: float = 72.0) -> float:
    """지수 시간 감쇠 가중치 (72시간 반감기)"""
    if pub is None:
        return 0.5
    ref = reference or datetime.now(timezone.utc)
    age_h = max(0.0, (ref - pub).total_seconds() / 3600)
    return 0.5 ** (age_h / half_life_hours)


# ============================================================
# 개별 소스 fetcher
# ============================================================
def fetch_google_news(keyword: str, lang: str = "ko", country: str = "KR",
                     max_items: int = 50) -> List[Dict]:
    """Google News RSS 검색"""
    q = urllib.parse.quote(keyword)
    url = f"https://news.google.com/rss/search?q={q}&hl={lang}&gl={country}&ceid={country}:{lang}"
    out = []
    try:
        data = _http_get(url, timeout=8)
        root = ET.fromstring(data)
        for item in root.findall(".//item")[:max_items]:
            title = _strip_html(item.findtext("title", ""))
            if not title:
                continue
            link  = item.findtext("link", "")
            pub_s = item.findtext("pubDate", "")
            desc  = _strip_html(item.findtext("description", ""))
            source_el = item.find("source")
            source_name = source_el.text if source_el is not None else "GoogleNews"
            pub = _parse_pubdate(pub_s)
            out.append({
                "title":  title,
                "text":   desc[:200],
                "url":    link,
                "source": f"GoogleNews/{source_name}",
                "lang":   lang,
                "published_at": pub.isoformat() if pub else None,
                "time_weight":  _time_weight(pub),
                "origin":       "google_news",
            })
    except Exception as e:
        print(f"  [GoogleNews '{keyword}' SKIP] {type(e).__name__}: {str(e)[:60]}")
    return out


def fetch_rss(name: str, url: str, max_items: int = 50) -> List[Dict]:
    """일반 RSS 피드"""
    out = []
    try:
        data = _http_get(url, timeout=8)
        root = ET.fromstring(data)
        items = root.findall(".//item")
        for item in items[:max_items]:
            title = _strip_html(item.findtext("title", ""))
            if not title:
                continue
            link  = item.findtext("link", "")
            pub_s = item.findtext("pubDate", "") or item.findtext("{http://purl.org/dc/elements/1.1/}date", "")
            desc  = _strip_html(item.findtext("description", ""))
            pub = _parse_pubdate(pub_s)
            out.append({
                "title":  title,
                "text":   desc[:200],
                "url":    link,
                "source": name,
                "lang":   "ko" if any(k in name for k in ["연합","매경","한경","한국"]) else "en",
                "published_at": pub.isoformat() if pub else None,
                "time_weight":  _time_weight(pub),
                "origin":       "rss",
            })
    except Exception as e:
        print(f"  [RSS '{name}' SKIP] {type(e).__name__}: {str(e)[:60]}")
    return out


def fetch_naver(keyword: str, max_items: int = 100) -> List[Dict]:
    """네이버 뉴스 검색 API — .env에 NAVER_CLIENT_ID/SECRET 있을 때만 동작"""
    cid = os.environ.get("NAVER_CLIENT_ID", "")
    csec = os.environ.get("NAVER_CLIENT_SECRET", "")
    if not (cid and csec):
        return []  # 키 없으면 비활성
    q = urllib.parse.quote(keyword)
    url = f"https://openapi.naver.com/v1/search/news.json?query={q}&display={min(max_items,100)}&sort=date"
    out = []
    try:
        data = _http_get(url, timeout=8, headers={
            "X-Naver-Client-Id":     cid,
            "X-Naver-Client-Secret": csec,
        })
        j = json.loads(data)
        for item in j.get("items", []):
            title = _strip_html(item.get("title", ""))
            if not title:
                continue
            desc = _strip_html(item.get("description", ""))
            pub  = _parse_pubdate(item.get("pubDate", ""))
            out.append({
                "title":  title,
                "text":   desc[:200],
                "url":    item.get("originallink") or item.get("link", ""),
                "source": "NaverNews",
                "lang":   "ko",
                "published_at": pub.isoformat() if pub else None,
                "time_weight":  _time_weight(pub),
                "origin":       "naver",
            })
    except Exception as e:
        print(f"  [Naver '{keyword}' SKIP] {type(e).__name__}: {str(e)[:60]}")
    return out


def fetch_gdelt_now(keyword: str = None, hours_back: int = 24, max_items: int = 75) -> List[Dict]:
    """GDELT 최근 N시간 뉴스 (실시간 예측용). 기존 news_collector.py와 별개로 직접 호출."""
    kw = keyword or '"South Korea" (won OR KRW OR currency OR economy OR exchange)'
    end = datetime.now(timezone.utc)
    start = end - timedelta(hours=hours_back)
    params = {
        "query":      kw,
        "mode":       "ArtList",
        "format":     "json",
        "maxrecords": str(max_items),
        "sort":       "DateDesc",
        "startdatetime": start.strftime("%Y%m%d%H%M%S"),
        "enddatetime":   end.strftime("%Y%m%d%H%M%S"),
    }
    url = "https://api.gdeltproject.org/api/v2/doc/doc?" + urllib.parse.urlencode(params)
    out = []
    try:
        data = _http_get(url, timeout=10)
        j = json.loads(data) if data.strip().startswith("{") else {"articles": []}
        for art in j.get("articles", []):
            title = art.get("title", "")
            if not title:
                continue
            pub_s = art.get("seendate", "")
            pub = None
            if pub_s:
                try:
                    pub = datetime.strptime(pub_s, "%Y%m%dT%H%M%SZ").replace(tzinfo=timezone.utc)
                except Exception:
                    pass
            out.append({
                "title":  title,
                "text":   "",
                "url":    art.get("url", ""),
                "source": f"GDELT/{art.get('domain','')}",
                "lang":   art.get("language", "en"),
                "published_at": pub.isoformat() if pub else None,
                "time_weight":  _time_weight(pub),
                "origin":       "gdelt",
            })
    except Exception as e:
        print(f"  [GDELT SKIP] {type(e).__name__}: {str(e)[:60]}")
    return out


# ============================================================
# 통합 수집기
# ============================================================
def collect_all(hours_back: int = 24, max_per_source: int = 50,
                include_gdelt: bool = True, verbose: bool = True) -> Dict:
    """
    모든 소스에서 최근 hours_back 시간 내 환율 관련 뉴스 통합 수집.
    중복 제거 (URL → 정규화 title) 후 반환.
    """
    bucket: Dict[str, Dict] = {}  # key: url 또는 title → 기사
    source_stats: Dict[str, int] = {}

    def _add(items: List[Dict], src_label: str):
        added = 0
        for a in items:
            key = a.get("url") or a.get("title", "")
            if not key:
                continue
            if key in bucket:
                # 이미 있으면 더 최신 time_weight 채택
                if a.get("time_weight", 0) > bucket[key].get("time_weight", 0):
                    bucket[key] = a
                continue
            bucket[key] = a
            added += 1
        source_stats[src_label] = source_stats.get(src_label, 0) + added

    # 1) Google News (한+영 키워드)
    if verbose:
        print(f"[multi-source] Google News RSS 수집 ({len(KO_KEYWORDS)+len(EN_KEYWORDS)}개 키워드)...")
    for kw in KO_KEYWORDS:
        _add(fetch_google_news(kw, "ko", "KR", max_per_source), f"GoogleNews/{kw}")
        time.sleep(0.3)
    for kw in EN_KEYWORDS:
        _add(fetch_google_news(kw, "en", "US", max_per_source), f"GoogleNews/{kw}")
        time.sleep(0.3)

    # 2) RSS 피드
    if verbose:
        print(f"[multi-source] RSS 피드 수집 ({len(RSS_FEEDS)}개)...")
    for name, url in RSS_FEEDS.items():
        _add(fetch_rss(name, url, max_per_source), f"RSS/{name}")
        time.sleep(0.2)

    # 3) 네이버 (있으면)
    if os.environ.get("NAVER_CLIENT_ID"):
        if verbose:
            print(f"[multi-source] 네이버 뉴스 API 수집 ({len(KO_KEYWORDS)}개 키워드)...")
        for kw in KO_KEYWORDS:
            _add(fetch_naver(kw, 50), f"Naver/{kw}")
            time.sleep(0.2)
    elif verbose:
        print("[multi-source] 네이버 API: 키 없음 (건너뜀)")

    # 4) GDELT (실시간)
    if include_gdelt:
        if verbose:
            print(f"[multi-source] GDELT 최근 {hours_back}시간 수집...")
        _add(fetch_gdelt_now(hours_back=hours_back, max_items=75), "GDELT/realtime")

    # 최신순 정렬
    articles = sorted(
        bucket.values(),
        key=lambda a: a.get("published_at") or "",
        reverse=True,
    )

    return {
        "total":    len(articles),
        "articles": articles,
        "by_source": source_stats,
    }


# ============================================================
# CLI 테스트
# ============================================================
if __name__ == "__main__":
    import sys
    from dotenv import load_dotenv
    load_dotenv(".env")

    hours = int(sys.argv[1]) if len(sys.argv) > 1 else 24

    print("=" * 70)
    print(f"  NEXUS 멀티 소스 뉴스 수집기 — 최근 {hours}시간")
    print("=" * 70)

    t0 = time.time()
    result = collect_all(hours_back=hours, verbose=True)
    dt = time.time() - t0

    print()
    print(f"=== 결과: 총 {result['total']}건 (수집 시간: {dt:.1f}s) ===")
    print()
    print(f"  {'소스':<40} 추가 기사")
    print(f"  {'-'*40} {'-'*8}")
    for src, n in sorted(result["by_source"].items(), key=lambda x: -x[1]):
        if n > 0:
            print(f"  {src[:40]:<40} {n:>6}건")

    print()
    print("[샘플 — 최신 10건]")
    for a in result["articles"][:10]:
        pub = a.get("published_at", "")[:16] if a.get("published_at") else "?"
        src = a["source"][:18]
        print(f"  [{pub}] [{src:<18}] {a['title'][:65]}")
