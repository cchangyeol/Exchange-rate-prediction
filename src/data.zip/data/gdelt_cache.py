"""
GDELT API 응답 SQLite 캐시
==========================

GDELT는 IP별 rate-limit이 강해 동일 query 반복 호출이 비현실적.
이 모듈은 (keyword, start_dt, end_dt) 키로 article list를 캐싱하여:
  - 첫 호출만 GDELT를 두드림
  - 이후 동일 query는 캐시에서 즉시 반환
  - CSV 백테스트를 며칠에 걸쳐 점진 실행해도 진척이 사라지지 않음

스키마:
  queries(id, key, keyword, start_dt, end_dt, fetched_at, status, error)
  articles(id, query_id, title, url, source, published_at, time_weight)
"""
import hashlib
import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

# DB 는 프로젝트 루트의 data/ 디렉토리에 저장
# 파일 위치: src/data/gdelt_cache.py → parents[2] = 프로젝트 루트
_PROJECT_ROOT = Path(__file__).resolve().parents[2]
_DATA_DIR = _PROJECT_ROOT / "data"
_DATA_DIR.mkdir(parents=True, exist_ok=True)
CACHE_PATH = str(_DATA_DIR / "gdelt_cache.db")


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(CACHE_PATH)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS queries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key TEXT UNIQUE NOT NULL,
            keyword TEXT NOT NULL,
            start_dt TEXT NOT NULL,
            end_dt TEXT NOT NULL,
            fetched_at TEXT NOT NULL,
            status TEXT NOT NULL,
            article_count INTEGER NOT NULL,
            error TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS articles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            query_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            url TEXT,
            source TEXT,
            published_at TEXT,
            time_weight REAL,
            FOREIGN KEY(query_id) REFERENCES queries(id) ON DELETE CASCADE
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_articles_query ON articles(query_id)")
    return conn


def _make_key(keyword: str, start_dt: datetime, end_dt: datetime) -> str:
    """Cache key — keyword와 날짜 분 단위까지 정밀"""
    s = f"{keyword}::{start_dt.strftime('%Y%m%d%H%M')}::{end_dt.strftime('%Y%m%d%H%M')}"
    return hashlib.sha256(s.encode()).hexdigest()[:32]


def get_cached(keyword: str, start_dt: datetime, end_dt: datetime) -> Optional[List[Dict]]:
    """캐시 hit이면 article list 반환, miss면 None"""
    key = _make_key(keyword, start_dt, end_dt)
    conn = _connect()
    try:
        cur = conn.execute("SELECT id, status FROM queries WHERE key=?", (key,))
        row = cur.fetchone()
        if not row:
            return None
        query_id, status = row
        # status가 'ok'가 아니면 (예: 'error') 캐시 무시 — 재호출 유도
        if status != "ok":
            return None
        cur = conn.execute("""
            SELECT title, url, source, published_at, time_weight
            FROM articles WHERE query_id=?
        """, (query_id,))
        articles = []
        for title, url, source, pub, tw in cur.fetchall():
            articles.append({
                "title":        title,
                "text":         "",
                "url":          url or "",
                "source":       source or "",
                "lang":         "en",
                "published_at": pub,
                "raw_weight":   1.0,
                "time_weight":  tw or 0.0,
                "final_weight": round(tw or 0.0, 4),
            })
        return articles
    finally:
        conn.close()


def put_cached(keyword: str, start_dt: datetime, end_dt: datetime,
               articles: List[Dict], status: str = "ok", error: str = "") -> None:
    """캐시에 저장. status='ok'이어야 다음 get_cached가 hit으로 처리"""
    key = _make_key(keyword, start_dt, end_dt)
    now = datetime.now(timezone.utc).isoformat()
    conn = _connect()
    try:
        # upsert
        conn.execute("""
            INSERT INTO queries(key,keyword,start_dt,end_dt,fetched_at,status,article_count,error)
            VALUES (?,?,?,?,?,?,?,?)
            ON CONFLICT(key) DO UPDATE SET
                fetched_at=excluded.fetched_at,
                status=excluded.status,
                article_count=excluded.article_count,
                error=excluded.error
        """, (key, keyword, start_dt.isoformat(), end_dt.isoformat(),
              now, status, len(articles), error))
        cur = conn.execute("SELECT id FROM queries WHERE key=?", (key,))
        query_id = cur.fetchone()[0]
        # 기존 articles 삭제 후 재삽입
        conn.execute("DELETE FROM articles WHERE query_id=?", (query_id,))
        for a in articles:
            conn.execute("""
                INSERT INTO articles(query_id,title,url,source,published_at,time_weight)
                VALUES (?,?,?,?,?,?)
            """, (query_id, a.get("title",""), a.get("url",""), a.get("source",""),
                  a.get("published_at"), a.get("time_weight", 0.0)))
        conn.commit()
    finally:
        conn.close()


def stats() -> Dict:
    """캐시 통계"""
    if not os.path.exists(CACHE_PATH):
        return {"queries": 0, "articles": 0, "size_kb": 0}
    conn = _connect()
    try:
        nq = conn.execute("SELECT COUNT(*) FROM queries WHERE status='ok'").fetchone()[0]
        na = conn.execute("SELECT COUNT(*) FROM articles").fetchone()[0]
        size = os.path.getsize(CACHE_PATH) // 1024
        return {"queries": nq, "articles": na, "size_kb": size}
    finally:
        conn.close()


if __name__ == "__main__":
    s = stats()
    print(f"GDELT 캐시: {s['queries']} queries / {s['articles']} articles / {s['size_kb']} KB")
