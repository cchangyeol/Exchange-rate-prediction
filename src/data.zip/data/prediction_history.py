"""
NEXUS 예측 이력 저장/조회 시스템 (SQLite)
=========================================

각 앙상블 예측 결과를 저장하고, T+horizon 후 실제 환율 변동과 비교하여
누적 정확도를 추적.

스키마:
  predictions
    - id, timestamp, ticker, horizon
    - rate_at_prediction (예측 당시 환율)
    - per_exp_json (V1~V5 각각 pred_pct, JSON)
    - strategy_a_dir, strategy_a_avg, strategy_a_triggered
    - strategy_b_dir, strategy_b_up, strategy_b_down, strategy_b_triggered
    - consensus_dir
    - news_total, news_sources_json
    - elapsed_sec

  outcomes (예측 검증 결과)
    - prediction_id (FK), verified_at
    - rate_at_target (T+horizon 시점 실제 환율)
    - actual_pct (실제 변동률)
    - actual_dir ('up'/'down')
    - match_a, match_b, match_consensus (각 전략과 일치 여부)
"""
import json
import os
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional

# DB 는 프로젝트 루트의 data/ 디렉토리에 저장
# 파일 위치: src/data/prediction_history.py → parents[2] = 프로젝트 루트
_PROJECT_ROOT = Path(__file__).resolve().parents[2]
_DATA_DIR = _PROJECT_ROOT / "data"
_DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = str(_DATA_DIR / "prediction_history.db")


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS predictions (
            id                    INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp             TEXT NOT NULL,
            ticker                TEXT NOT NULL,
            horizon               INTEGER NOT NULL,
            rate_at_prediction    REAL,
            per_exp_json          TEXT NOT NULL,
            strategy_a_dir        TEXT,
            strategy_a_avg        REAL,
            strategy_a_triggered  INTEGER,
            strategy_b_dir        TEXT,
            strategy_b_up         INTEGER,
            strategy_b_down       INTEGER,
            strategy_b_triggered  INTEGER,
            consensus_dir         TEXT,
            news_total            INTEGER,
            news_sources_json     TEXT,
            elapsed_sec           REAL,
            target_date           TEXT NOT NULL  -- timestamp + horizon 거래일
        );
        CREATE INDEX IF NOT EXISTS idx_pred_ticker_h ON predictions(ticker, horizon);
        CREATE INDEX IF NOT EXISTS idx_pred_target   ON predictions(target_date);

        CREATE TABLE IF NOT EXISTS outcomes (
            prediction_id    INTEGER PRIMARY KEY,
            verified_at      TEXT NOT NULL,
            rate_at_target   REAL,
            actual_pct       REAL,
            actual_dir       TEXT,
            match_a          INTEGER,
            match_b          INTEGER,
            match_consensus  INTEGER,
            FOREIGN KEY(prediction_id) REFERENCES predictions(id) ON DELETE CASCADE
        );
    """)
    return conn


# ============================================================
# 저장
# ============================================================
def save_prediction(result: Dict, rate_at_prediction: Optional[float] = None) -> int:
    """
    predict_ensemble.predict() 결과 dict를 받아 DB에 저장. row id 반환.
    rate_at_prediction이 None이면 yfinance로 즉시 조회.
    """
    if rate_at_prediction is None:
        rate_at_prediction = _fetch_rate_now(result["ticker"])

    ens = result["ensemble"]
    sa  = ens["strategy_a"]
    sb  = ens["strategy_b"]
    cons = ens["consensus"]

    # target_date: 예측 시점 + horizon 영업일 (대략)
    horizon = int(result["horizon"])
    pred_ts = datetime.fromisoformat(result["timestamp"].replace("Z", "+00:00"))
    target  = pred_ts + timedelta(days=horizon)  # 단순화 — 검증 시 nearest trading day로 보정

    conn = _connect()
    try:
        cur = conn.execute("""
            INSERT INTO predictions (
                timestamp, ticker, horizon, rate_at_prediction,
                per_exp_json,
                strategy_a_dir, strategy_a_avg, strategy_a_triggered,
                strategy_b_dir, strategy_b_up, strategy_b_down, strategy_b_triggered,
                consensus_dir,
                news_total, news_sources_json,
                elapsed_sec, target_date
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            result["timestamp"],
            result["ticker"],
            horizon,
            rate_at_prediction,
            json.dumps(ens["per_exp"], ensure_ascii=False),
            sa["direction"], sa["avg_pred"], int(sa["triggered"]),
            sb["direction"],
            sb["strong_signals"]["up"], sb["strong_signals"]["down"],
            int(sb["triggered"]),
            cons["direction"] or "none",
            result["news"]["total"],
            json.dumps(result["news"]["by_source"], ensure_ascii=False),
            result.get("elapsed_sec", 0.0),
            target.isoformat(),
        ))
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


# ============================================================
# 결과 검증 (T+horizon 도래한 예측의 실제 결과를 채워 넣음)
# ============================================================
def verify_pending(now: Optional[datetime] = None, verbose: bool = False) -> int:
    """
    target_date가 지난 예측 중 outcome이 없는 것들을
    yfinance로 실제 환율 확인 후 outcomes 테이블에 저장.
    반환: 검증한 row 수
    """
    now = now or datetime.now(timezone.utc)
    conn = _connect()
    try:
        cur = conn.execute("""
            SELECT p.id, p.timestamp, p.ticker, p.horizon, p.rate_at_prediction,
                   p.strategy_a_dir, p.strategy_a_triggered,
                   p.strategy_b_dir, p.strategy_b_triggered,
                   p.consensus_dir, p.target_date
            FROM predictions p
            LEFT JOIN outcomes o ON o.prediction_id = p.id
            WHERE o.prediction_id IS NULL
              AND p.target_date <= ?
        """, (now.isoformat(),))
        rows = cur.fetchall()
    finally:
        conn.close()

    verified = 0
    for row in rows:
        pid, ts, ticker, horizon, rate_pred, sa_dir, sa_trig, sb_dir, sb_trig, cons_dir, target_date = row
        # 실제 T+horizon 시점 환율 조회
        target = datetime.fromisoformat(target_date.replace("Z", "+00:00"))
        actual_rate = _fetch_rate_at(ticker, target)
        if actual_rate is None or rate_pred is None or rate_pred == 0:
            if verbose:
                print(f"  [SKIP] pred_id={pid} {ticker} — 환율 조회 실패")
            continue

        actual_pct = (actual_rate - rate_pred) / rate_pred * 100
        actual_dir = "up" if actual_pct >= 0 else "down"

        m_a = int(sa_trig and sa_dir == actual_dir) if sa_trig else None
        m_b = int(sb_trig and sb_dir == actual_dir) if sb_trig else None
        m_c = int(cons_dir == actual_dir) if cons_dir and cons_dir != "none" else None

        conn = _connect()
        try:
            conn.execute("""
                INSERT INTO outcomes (
                    prediction_id, verified_at, rate_at_target, actual_pct, actual_dir,
                    match_a, match_b, match_consensus
                ) VALUES (?,?,?,?,?,?,?,?)
            """, (pid, now.isoformat(), actual_rate, actual_pct, actual_dir, m_a, m_b, m_c))
            conn.commit()
        finally:
            conn.close()
        verified += 1
        if verbose:
            print(f"  [OK] pred_id={pid} {ticker} T+{horizon}: pred={sa_dir}/{sb_dir} actual={actual_dir} ({actual_pct:+.3f}%)")

    return verified


# ============================================================
# 조회
# ============================================================
def list_recent(limit: int = 30, ticker: Optional[str] = None) -> List[Dict]:
    """최근 예측 이력 (outcome 포함)"""
    conn = _connect()
    try:
        sql = """
            SELECT p.id, p.timestamp, p.ticker, p.horizon, p.rate_at_prediction,
                   p.strategy_a_dir, p.strategy_a_avg, p.strategy_a_triggered,
                   p.strategy_b_dir, p.strategy_b_up, p.strategy_b_down, p.strategy_b_triggered,
                   p.consensus_dir, p.news_total, p.target_date,
                   o.rate_at_target, o.actual_pct, o.actual_dir,
                   o.match_a, o.match_b, o.match_consensus
            FROM predictions p
            LEFT JOIN outcomes o ON o.prediction_id = p.id
        """
        params = []
        if ticker:
            sql += " WHERE p.ticker = ?"
            params.append(ticker)
        sql += " ORDER BY p.id DESC LIMIT ?"
        params.append(limit)
        rows = conn.execute(sql, params).fetchall()
    finally:
        conn.close()

    keys = ["id","timestamp","ticker","horizon","rate_at_prediction",
            "strategy_a_dir","strategy_a_avg","strategy_a_triggered",
            "strategy_b_dir","strategy_b_up","strategy_b_down","strategy_b_triggered",
            "consensus_dir","news_total","target_date",
            "rate_at_target","actual_pct","actual_dir",
            "match_a","match_b","match_consensus"]
    return [dict(zip(keys, r)) for r in rows]


def accuracy_summary(ticker: Optional[str] = None) -> Dict:
    """누적 정확도 통계"""
    conn = _connect()
    try:
        where = ""
        params = []
        if ticker:
            where = " WHERE p.ticker = ?"
            params.append(ticker)
        sql = f"""
            SELECT
                COUNT(*)                                            AS total_preds,
                SUM(CASE WHEN o.prediction_id IS NOT NULL THEN 1 ELSE 0 END) AS verified,
                AVG(CASE WHEN o.match_a IS NOT NULL THEN o.match_a*1.0 END)         AS acc_a,
                SUM(CASE WHEN o.match_a IS NOT NULL THEN 1 ELSE 0 END) AS n_a,
                AVG(CASE WHEN o.match_b IS NOT NULL THEN o.match_b*1.0 END)         AS acc_b,
                SUM(CASE WHEN o.match_b IS NOT NULL THEN 1 ELSE 0 END) AS n_b,
                AVG(CASE WHEN o.match_consensus IS NOT NULL THEN o.match_consensus*1.0 END) AS acc_c,
                SUM(CASE WHEN o.match_consensus IS NOT NULL THEN 1 ELSE 0 END) AS n_c
            FROM predictions p
            LEFT JOIN outcomes o ON o.prediction_id = p.id
            {where}
        """
        row = conn.execute(sql, params).fetchone()
    finally:
        conn.close()

    total, verified, acc_a, n_a, acc_b, n_b, acc_c, n_c = row
    def _pct(v): return None if v is None else round(v * 100, 1)
    return {
        "total_predictions": total or 0,
        "verified": verified or 0,
        "pending":  (total or 0) - (verified or 0),
        "strategy_a": {"accuracy_pct": _pct(acc_a), "n": n_a or 0},
        "strategy_b": {"accuracy_pct": _pct(acc_b), "n": n_b or 0},
        "consensus":  {"accuracy_pct": _pct(acc_c), "n": n_c or 0},
    }


def by_ticker_summary() -> List[Dict]:
    """통화별 통계"""
    conn = _connect()
    try:
        rows = conn.execute("""
            SELECT p.ticker, p.horizon,
                   COUNT(*) AS total,
                   SUM(CASE WHEN o.prediction_id IS NOT NULL THEN 1 ELSE 0 END) AS verified,
                   AVG(CASE WHEN o.match_a IS NOT NULL THEN o.match_a*1.0 END) AS acc_a,
                   AVG(CASE WHEN o.match_b IS NOT NULL THEN o.match_b*1.0 END) AS acc_b,
                   AVG(CASE WHEN o.match_consensus IS NOT NULL THEN o.match_consensus*1.0 END) AS acc_c
            FROM predictions p
            LEFT JOIN outcomes o ON o.prediction_id = p.id
            GROUP BY p.ticker, p.horizon
            ORDER BY p.ticker, p.horizon
        """).fetchall()
    finally:
        conn.close()
    out = []
    for ticker, horizon, total, verified, acc_a, acc_b, acc_c in rows:
        out.append({
            "ticker": ticker, "horizon": horizon,
            "total": total, "verified": verified or 0,
            "acc_a": None if acc_a is None else round(acc_a * 100, 1),
            "acc_b": None if acc_b is None else round(acc_b * 100, 1),
            "acc_c": None if acc_c is None else round(acc_c * 100, 1),
        })
    return out


# ============================================================
# yfinance 헬퍼
# ============================================================
def _fetch_rate_now(ticker: str) -> Optional[float]:
    try:
        import yfinance as yf
        info = yf.Ticker(ticker).fast_info
        return float(info.last_price)
    except Exception:
        return None


def _fetch_rate_at(ticker: str, target_dt: datetime) -> Optional[float]:
    """target_dt 가장 가까운 거래일의 종가 (이후 방향) — 보통 +0~3 day 윈도우에서 찾음"""
    try:
        import yfinance as yf
        # 7일 안에서 가장 가까운 종가 찾음
        start = target_dt - timedelta(days=2)
        end   = target_dt + timedelta(days=5)
        df = yf.Ticker(ticker).history(
            start=start.strftime("%Y-%m-%d"),
            end=end.strftime("%Y-%m-%d"),
            interval="1d",
        )
        if df.empty:
            return None
        # target_dt 이후 첫 거래일
        target_date_only = target_dt.date()
        for idx, row in df.iterrows():
            row_date = idx.date()
            if row_date >= target_date_only:
                return float(row["Close"])
        return float(df["Close"].iloc[-1])
    except Exception:
        return None


# ============================================================
# CLI
# ============================================================
if __name__ == "__main__":
    import sys
    cmd = sys.argv[1] if len(sys.argv) > 1 else "summary"

    if cmd == "summary":
        print("=" * 65)
        print("  예측 이력 누적 통계")
        print("=" * 65)
        s = accuracy_summary()
        print(f"  전체 예측: {s['total_predictions']}개")
        print(f"  검증 완료: {s['verified']}개  /  대기중: {s['pending']}개")
        print()
        for k, label in [("strategy_a","전략 A (평균+필터)"),
                         ("strategy_b","전략 B (콘센서스)"),
                         ("consensus","두 전략 합의")]:
            v = s[k]
            acc = f"{v['accuracy_pct']}%" if v["accuracy_pct"] is not None else "—"
            print(f"  {label:24}: {acc:>8}  (N={v['n']})")

        print()
        print("=" * 65)
        print("  통화별 매트릭스")
        print("=" * 65)
        rows = by_ticker_summary()
        if not rows:
            print("  (아직 예측 기록 없음)")
        else:
            print(f"  {'Ticker':<10} {'H':>3} {'Total':>5} {'Verified':>9}  {'A%':>6} {'B%':>6} {'Cons%':>6}")
            for r in rows:
                a = f"{r['acc_a']:.0f}" if r['acc_a'] is not None else "—"
                b = f"{r['acc_b']:.0f}" if r['acc_b'] is not None else "—"
                c = f"{r['acc_c']:.0f}" if r['acc_c'] is not None else "—"
                print(f"  {r['ticker']:<10} T+{r['horizon']:<2} {r['total']:>5} {r['verified']:>9}  {a:>6} {b:>6} {c:>6}")

    elif cmd == "verify":
        n = verify_pending(verbose=True)
        print(f"\n검증 완료: {n}건")

    elif cmd == "recent":
        rows = list_recent(limit=20)
        print(f"최근 {len(rows)}건:")
        for r in rows:
            ts = r['timestamp'][:16].replace("T"," ")
            res = "✓" if r['match_consensus']==1 else ("✗" if r['match_consensus']==0 else "?")
            actual = f"{r['actual_pct']:+.2f}%" if r['actual_pct'] is not None else "pending"
            print(f"  [{ts}] {r['ticker']} T+{r['horizon']}  pred={r['consensus_dir']:<5} actual={actual:<10} {res}")

    else:
        print("사용: python prediction_history.py [summary|verify|recent]")
